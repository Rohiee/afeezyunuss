<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<div class="vlt-content-protected">

	<?php echo get_the_password_form(); ?>

</div>
<!-- /.vlt-content-protected -->