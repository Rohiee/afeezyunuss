<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<h1 class="vlt-post-title"><?php the_title(); ?></h1>
<!-- /.vlt-post-title -->