<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<h1><?php the_title(); ?></h1>

		<?php echo gilber_get_breadcrumbs(); ?>

	</div>

</div>
<!-- /.vlt-page-title -->