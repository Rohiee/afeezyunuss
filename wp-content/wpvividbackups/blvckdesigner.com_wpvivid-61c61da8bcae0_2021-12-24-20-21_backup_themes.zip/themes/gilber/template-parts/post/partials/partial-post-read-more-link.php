<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<a class="vlt-read-more-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'gilber' ); ?><svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8"><defs></defs><path d="M15.3536 4.35355c.1952-.19526.1952-.51184 0-.7071L12.1716.464466c-.1953-.195262-.5119-.195262-.7071 0-.1953.195262-.1953.511845 0 .707104L14.2929 4l-2.8284 2.82843c-.1953.19526-.1953.51184 0 .7071.1952.19527.5118.19527.7071 0l3.182-3.18198zM0 4.5h15v-1H0v1z" fill="currentColor"></path></svg></a>
<!-- /.vlt-read-more-link -->